var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{class:this.$route.meta.bodyClass,attrs:{"id":"app"}},[_c('BgBody'),_c('Header',{attrs:{"routeName":this.$route.name,"viewport":_vm.viewport}}),_c('transition',{attrs:{"appear":"","mode":"out-in","css":false},on:{"leave":_vm.leave,"enter":_vm.enter}},[_c('router-view',{attrs:{"viewport":_vm.viewport}})],1),_c('Spine')],1)}
var staticRenderFns = []

export { render, staticRenderFns }