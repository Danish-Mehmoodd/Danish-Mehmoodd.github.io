var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _vm._m(0)}
var staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('div',{staticClass:"spine"}),_c('div',{staticClass:"spine-target"},[_c('div',{staticClass:"circle"}),_c('div',{staticClass:"pulse"})])])}]

export { render, staticRenderFns }