var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"scene",attrs:{"id":_vm.scene}},[_c('div',{staticClass:"title-container"},[_vm._t("default")],2)])}
var staticRenderFns = []

export { render, staticRenderFns }