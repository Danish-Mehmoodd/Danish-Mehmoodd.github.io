<template>
    <section class="scene-intro" id="intro">
        <div class="static-container">
            <h1 class="title">
                <span class="iuri">iuri</span>
                <span class="func">.is()</span>
            </h1>

            <div class="std">
                <p class="-purple">Iuri de Paula</p>
                <p class="-gray">
                    Creative frontend developer,<br>
                    designer, and illustrator.
                </p>
            </div>
        </div>
    </section>
</template>

<script>
    export default {
        name: 'Intro'
    }
</script>