import { render, staticRenderFns } from "./Wrapper.vue?vue&type=template&id=bbba3ef6&"
import script from "./Wrapper.vue?vue&type=script&lang=js&"
export * from "./Wrapper.vue?vue&type=script&lang=js&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports